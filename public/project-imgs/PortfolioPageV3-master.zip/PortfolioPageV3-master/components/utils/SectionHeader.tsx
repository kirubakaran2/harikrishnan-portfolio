import styles from "./header.module.scss";
import { Reveal } from "./Reveal";

interface Props {
  title: string;
  dir?: "l" | "r";
}

export const SectionHeader = ({ title, dir = "r" }: Props) => {
  return (
    <div
      className={styles.sectionHeader}
      style={{
        flexDirection: dir === "r" ? "row" : "row-reverse",
      }}
    >
      <div className={styles.line} />
      <h3 style={{ minWidth: "max-content" }}>
        <Reveal>
          <span className={styles.title}>
            {title}
            <span>.</span>
          </span>
        </Reveal>
      </h3>
    </div>
  );
};
